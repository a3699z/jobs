<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Newsletter\\Providers\\NewsletterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Newsletter\\Providers\\NewsletterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);