<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Testimonial\\Providers\\TestimonialServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Testimonial\\Providers\\TestimonialServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);