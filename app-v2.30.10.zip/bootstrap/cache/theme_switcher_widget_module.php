<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ThemeSwitcherWidget\\Providers\\ThemeSwitcherWidgetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ThemeSwitcherWidget\\Providers\\ThemeSwitcherWidgetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);