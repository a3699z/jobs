<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SetupGuide\\Providers\\SetupGuideServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SetupGuide\\Providers\\SetupGuideServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);